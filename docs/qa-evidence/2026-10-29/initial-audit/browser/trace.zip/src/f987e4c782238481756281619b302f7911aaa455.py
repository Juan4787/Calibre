#!/usr/bin/env python3
"""Current UI regression gate: real Chromium, fresh DB, exact cells, actual navigation."""

import argparse
import hashlib
import http.server
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from copy import deepcopy
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from qa.reconcile import LABELS, display_money, reconcile  # noqa: E402


def assert_ipv4_loopback_listener(port):
    """Inspect the real Linux listener rather than inferring bind scope from a URL."""
    table = Path("/proc/net/tcp")
    if not table.exists():
        return "Listener inspection unavailable on this OS; browser and HTTP boundary still tested"
    listening = [
        row.split()[1]
        for row in table.read_text().splitlines()[1:]
        if row.split()[3] == "0A" and int(row.split()[1].split(":")[1], 16) == port
    ]
    assert listening == [f"0100007F:{port:04X}"], f"Unexpected listener scope: {listening}"
    return "127.0.0.1 only, inspected in /proc/net/tcp"


def exercise_cross_origin(browser_context, client, token, port):
    """A real foreign page cannot read the local API or create a run."""

    class ForeignPage(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body = b"<!doctype html><title>Foreign test origin</title>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_args):
            pass

    with http.server.ThreadingHTTPServer(("127.0.0.1", 0), ForeignPage) as foreign:
        thread = threading.Thread(target=foreign.serve_forever, daemon=True)
        thread.start()
        try:
            foreign_origin = f"http://127.0.0.1:{foreign.server_port}"
            target = f"http://127.0.0.1:{port}"
            hostile = browser_context.new_page()
            try:
                hostile.goto(foreign_origin)
                for path, options in (
                    ("/api/session", {}),
                    ("/api/demo", {"method": "POST", "headers": {"X-Freight-Local": token}}),
                ):
                    observed = hostile.evaluate(
                        """async ({url, options}) => {
                            try {
                                const response = await fetch(url, options);
                                return {readable: true, status: response.status};
                            } catch (error) {
                                return {readable: false, error: String(error)};
                            }
                        }""",
                        {"url": target + path, "options": options},
                    )
                    assert not observed["readable"], f"Foreign origin read local API: {observed}"
            finally:
                hostile.close()
            for method, headers in (
                ("POST", {"Origin": foreign_origin, "X-Freight-Local": token}),
                (
                    "OPTIONS",
                    {
                        "Origin": foreign_origin,
                        "Access-Control-Request-Method": "POST",
                        "Access-Control-Request-Headers": "x-freight-local",
                    },
                ),
            ):
                response = client.request(method, "/api/demo", headers=headers)
                assert "access-control-allow-origin" not in response.headers
                if method == "POST":
                    assert response.status_code == 403
            assert client.get("/api/runs").json() == []
            return {"foreign_origin": foreign_origin, "browser_readable": False, "runs_created": 0}
        finally:
            foreign.shutdown()
            thread.join(timeout=5)


def observe(page, run):
    """Read all pages from the actual DOM; do not synthesize observations from API data."""
    from playwright.sync_api import expect

    page.locator("#filter-status").select_option("")
    page.locator("#search").fill("")
    observations = {}
    while True:
        for row in page.locator("#findings tr[data-finding-id]").all():
            identifier = row.get_attribute("data-finding-id")
            assert identifier not in observations, "Duplicate row across pagination"
            observations[identifier] = [cell.inner_text().strip() for cell in row.locator("td").all()]
        if page.locator("#next").is_disabled():
            break
        page.locator("#next").click()
    assert set(observations) == {f["id"] for f in run["result"]["findings"]}
    for finding in run["result"]["findings"]:
        cells = observations[finding["id"]]
        assert cells[1] == LABELS[finding["status"]]
        assert cells[2] == finding["currency"] + " " + display_money(finding["actual"])
        empty = "Requiere revisión" if finding["status"] == "REVIEW" else "No determinable"
        assert cells[3] == (empty if finding["expected"] is None else display_money(finding["expected"]))
        difference = empty if finding["difference"] is None else display_money(finding["difference"])
        if finding["status"] == "REVIEW":
            difference += "\nRequiere revisión"
        assert cells[4] == difference
    while not page.locator("#prev").is_disabled():
        page.locator("#prev").click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    return observations


def exercise(page, client, destination):
    from playwright.sync_api import expect

    page.goto(str(client.base_url))
    assert page.locator("[style]:not([style=''])").count() == 0
    page.locator("#demo").click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    runs = client.get("/api/runs").json()
    assert len(runs) == 1
    run = client.get("/api/runs/" + runs[0]["id"]).json()
    original_hash = run["result_hash"]
    original_findings = run["result"]["findings"]
    observations = observe(page, run)
    # Independent handwritten anchors, in addition to channel consistency.
    by_charge = {cid: f for f in run["result"]["findings"] for cid in f["charge_ids"]}
    assert (by_charge["C-002"]["status"], by_charge["C-002"]["difference"]) == ("FAIL", "50")
    assert (by_charge["C-004"]["status"], by_charge["C-004"]["confirmed_difference"]) == ("REVIEW", "0")

    unknown = next(f for f in run["result"]["findings"] if f["version"] is None)
    page.locator("#filter-status").select_option("UNDETERMINABLE")
    page.locator(f'[data-finding="{unknown["id"]}"]').click()
    expect(page.locator("#detail-content")).to_contain_text("Sin versión aplicable")
    expect(page.locator("#detail-content")).to_contain_text("No se puede determinar la diferencia")
    expect(page.locator("#detail-content")).not_to_contain_text("R-BASE")
    expect(page.locator("#detail-content")).not_to_contain_text("Sin desviación")
    page.locator("#close-detail").click()

    page.locator("#filter-status").select_option("FAIL")
    target = by_charge["C-002"]
    difference_cell = page.locator(f'tr[data-finding-id="{target["id"]}"] td').nth(4)
    assert difference_cell.evaluate("element => getComputedStyle(element).color") == "rgb(158, 42, 43)"
    assert difference_cell.evaluate("element => getComputedStyle(element).fontWeight") == "750"
    assert page.locator("[style]:not([style=''])").count() == 0
    page.locator(f'[data-finding="{target["id"]}"]').click()
    assert page.locator("#detail-content [style]:not([style=''])").count() == 0
    for action, text in (("APPROVED", "Confirmado"), ("REJECTED", "Rechazado")):
        page.locator("#actor").fill("QA sintética")
        page.locator("#action").select_option(action)
        page.locator("#decision-note").fill("Prueba de historial conservado " + action)
        page.locator('#decision-form button[type="submit"]').click()
        expect(page.locator(".history").last).to_contain_text(text)
    page.locator("#close-detail").click()
    expect(page.locator(f'tr[data-finding-id="{target["id"]}"] td').nth(5)).to_have_text("Rechazado")
    run = client.get("/api/runs/" + run["id"]).json()
    assert run["result_hash"] == original_hash and len(run["decisions"]) == 2
    assert run["result"]["findings"] == original_findings
    page.locator("#replay").click()
    expect(page.locator("#notice")).to_contain_text("Reproducción idéntica")
    with page.expect_download() as downloading:
        page.get_by_text("Exportar JSON canónico", exact=True).click()
    download = downloading.value
    download.save_as(destination / "ui-export.json")
    assert json.loads((destination / "ui-export.json").read_text()) == run

    exported = client.get(f"/api/runs/{run['id']}/export/zip")
    exported.raise_for_status()
    bundle_path = destination / "audit.zip"
    bundle_path.write_bytes(exported.content)
    bundle_dir = destination / "export"
    with zipfile.ZipFile(bundle_path) as bundle:
        bundle.extractall(bundle_dir)  # Our fresh local server is the producer, not untrusted input.
    reconciled = reconcile(bundle_dir, api_run=run)
    assert not reconciled["errors"], reconciled
    reconciled["channels"]["ui"] = "46 actual DOM rows; all pages; exact cells and statuses"

    # Evidence from the actual form must create a new audit while preserving the original.
    page.locator("#filter-status").select_option("REVIEW")
    review = by_charge["C-004"]
    page.locator(f'[data-finding="{review["id"]}"]').click()
    page.locator("#evidence-panel summary").click()
    page.locator("#ev-kind").fill("authorization")
    page.locator("#ev-note").fill("Autorización ficticia para regresión")
    page.locator('#evidence-form button[type="submit"]').click()
    expect(page.locator("#detail")).not_to_be_visible()
    updated = next(r for r in client.get("/api/runs").json() if "evidencia adicional" in r["label"])
    resolved = client.get("/api/runs/" + updated["id"]).json()
    resolved_finding = next(f for f in resolved["result"]["findings"] if "C-004" in f["charge_ids"])
    assert resolved_finding["status"] == "PASS"
    assert client.get("/api/runs/" + run["id"]).json()["result"]["findings"] == original_findings

    # New wizard, including a response arriving after its file has changed.
    page.locator('[data-view="new"]').click()
    expect(page.locator("#file-shipments")).to_be_attached()
    page.locator("#step-nav-4").click()
    expect(page.locator("#step-panel-1")).to_be_visible()
    for role, filename in (("shipments", "operaciones.xlsx"), ("charges", "liquidacion.csv")):
        page.locator(f"#file-{role}").set_input_files(ROOT / "fixtures" / filename)
        page.locator(f"#mapping-file-{role}").set_input_files(ROOT / "fixtures" / f"mapping-{role}.json")
        expect(page.locator(f"#mapping-{role}")).to_have_value(
            (ROOT / "fixtures" / f"mapping-{role}.json").read_text()
        )
        expect(page.locator(f"#format-title-{role}")).to_have_text(
            f"Mapping manual: {'operaciones-demo' if role == 'shipments' else 'cargos-demo'}@1"
        )
        if role == "shipments":
            held = []

            def hold(route, _request, held=held):
                held.append((route, route.fetch()))

            page.route("**/api/import", hold)
            page.locator(f"#validate-{role}").click()
            for _ in range(100):
                if held:
                    break
                page.wait_for_timeout(20)
            assert held, "Import request did not reach server"
            page.locator(f"#file-{role}").set_input_files(
                {
                    "name": "operaciones-cambiadas.xlsx",
                    "mimeType": "application/octet-stream",
                    "buffer": (ROOT / "fixtures" / filename).read_bytes(),
                }
            )
            held[0][0].fulfill(response=held[0][1])
            expect(page.locator(f"#validate-{role}")).to_be_enabled()
            expect(page.locator(f"#result-{role}")).to_have_text(
                "Validar para ver filas aceptadas, rechazos y origen de los datos."
            )
            page.unroute("**/api/import", hold)
        page.locator(f"#validate-{role}").click()
        expect(page.locator(f"#result-{role}")).to_contain_text("filas aceptadas")
    page.locator("#audit-label").fill("QA interfaz actual")
    page.locator("#goto-step-2").click()
    page.locator("#agreement-file").set_input_files(ROOT / "fixtures/agreements.json")
    expect(page.locator("#agreements")).not_to_have_value("[]")
    page.locator("#goto-step-3").click()
    expect(page.locator("#step-summary-2-text")).to_contain_text("3 acuerdo(s)")
    expect(page.locator("#step-summary-2-text")).to_contain_text("5 versión(es)")
    expect(page.locator("#step-summary-2-text")).to_contain_text("10 regla(s) configuradas")
    for version in ("A-2026-H1", "A-2026-H2", "A-SOLAPADA", "B-1", "C-1"):
        expect(page.locator("#step-summary-2-text")).to_contain_text(version)
    page.locator("#step-summary-2-text summary").click()
    expect(page.locator("#step-summary-2-text ul").first).to_be_visible()
    expect(page.locator("#verify-charges-summary .import-issues summary")).to_contain_text("1 advertencia(s)")
    page.locator("#verify-charges-summary .import-issues summary").click()
    expect(page.locator("#verify-charges-summary .import-issues")).to_contain_text("Concepto sin clasificar")
    expect(page.locator("#step-panel-3 .banner.info")).to_contain_text(
        "Revisá las incidencias antes de ejecutar"
    )
    assert page.locator("#step-panel-3 [style]:not([style=''])").count() == 0
    page.screenshot(path=str(destination / "onr002-004-verification.png"), full_page=True)
    page.set_viewport_size({"width": 390, "height": 844})
    page.locator("#verify-charges-summary").scroll_into_view_if_needed()
    expect(page.locator("#verify-charges-summary .import-issues")).to_be_visible()
    page.screenshot(path=str(destination / "onr002-004-mobile.png"))
    page.set_viewport_size({"width": 1280, "height": 720})
    page.locator("#goto-step-4").click()
    expect(page.locator("#step-summary-3-text")).to_contain_text("1 incidencia(s) de importación")
    expect(page.locator("#step-summary-2-text")).to_contain_text("10 regla(s) configuradas")
    page.locator("#execute").click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    created = next(r for r in client.get("/api/runs").json() if r["label"] == "QA interfaz actual")
    imported = client.get("/api/runs/" + created["id"]).json()
    agreements = imported["snapshot"]["agreements"]
    assert len(agreements) == 3
    assert sum(len(agreement["versions"]) for agreement in agreements) == 5
    assert sum(len(version["rules"]) for agreement in agreements for version in agreement["versions"]) == 10
    assert any("Concepto sin clasificar" in issue["message"] for issue in imported["snapshot"]["issues"])
    unknown_concept = next(
        finding for finding in imported["result"]["findings"] if "C-008" in finding["charge_ids"]
    )
    assert unknown_concept["status"] == "UNDETERMINABLE"
    assert unknown_concept["actual"] == "432" and unknown_concept["confirmed_difference"] == "0"
    assert "operaciones-cambiadas.xlsx" in imported["snapshot"]["documents"].values()
    observe(page, imported)
    page.screenshot(path=str(destination / "current-ui.png"), full_page=True)
    page.reload()
    page.locator(f'[data-run="{run["id"]}"]').click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    observe(page, run)
    # Numeric boundary values have handwritten expectations; no float conversion in the oracle.
    snapshot = deepcopy(run["snapshot"])
    base_shipment = next(s for s in snapshot["shipments"] if s["reference"] == "00001")
    base_charge = next(c for c in snapshot["charges"] if c["id"] == "C-001")
    agreement = next(a for a in snapshot["agreements"] if a["id"] == "A")
    agreement["matching"]["duplicate_fields"] = []
    agreement["detect_missing"] = False
    agreement["versions"] = [agreement["versions"][0]]
    rule = deepcopy(agreement["versions"][0]["rules"][0])
    rule.update(
        expression={"op": "const", "value": {"type": "decimal", "value": "100", "unit": "ARS"}}, evidence=[]
    )
    agreement["versions"][0]["rules"] = [rule]
    snapshot.update(
        label="QA decimales extremos",
        shipments=[],
        charges=[],
        agreements=[agreement],
        evidence=[],
        coverage={},
    )
    numbers = {"BIG": "999999999999999999999999999999999999", "NEG": "-75.12", "ZERO": "0", "TOL": "100.01"}
    for identifier, amount in numbers.items():
        shipment = deepcopy(base_shipment)
        shipment.update(id=identifier, reference=identifier, provenance={})
        snapshot["shipments"].append(shipment)
        charge = deepcopy(base_charge)
        charge.update(id=identifier, reference=identifier, amount=amount, provenance={})
        snapshot["charges"].append(charge)
        if identifier == "BIG":
            snapshot["charges"].append({**charge, "id": "BIG2"})
    response = client.post("/api/audit", json=snapshot)
    response.raise_for_status()
    numeric_id = response.json()["run_id"]
    page.locator("#back").click()
    page.locator(f'[data-run="{numeric_id}"]').click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    numeric_run = client.get("/api/runs/" + numeric_id).json()
    numeric_findings = {f["shipment_ids"][0]: f for f in numeric_run["result"]["findings"]}
    assert numeric_findings["BIG"]["actual"] == str(2 * int(numbers["BIG"]))
    assert numeric_findings["NEG"]["difference"] == "-175.12"
    assert numeric_findings["ZERO"]["difference"] == "-100"
    assert numeric_findings["TOL"]["status"] == "PASS"
    observe(page, numeric_run)

    # A slow response for an old run must not replace the new-audit form.
    page.locator("#back").click()
    held_run = []

    def hold_run(route):
        held_run.append((route, route.fetch()))

    page.route(f"**/api/runs/{run['id']}", hold_run)
    page.locator(f'[data-run="{run["id"]}"]').click()
    for _ in range(100):
        if held_run:
            break
        page.wait_for_timeout(20)
    assert held_run
    page.locator('[data-view="new"]').click()
    expect(page.locator("#audit-label")).to_be_visible()
    held_run[0][0].fulfill(response=held_run[0][1])
    page.wait_for_timeout(100)
    expect(page.locator("#audit-label")).to_be_visible()
    expect(page.locator("#findings")).to_have_count(0)
    (destination / "observed-ui.json").write_text(json.dumps(observations, ensure_ascii=False, indent=2))
    return {
        "run_id": run["id"],
        "result_hash": original_hash,
        "rows_observed": len(observations),
        "channels": reconciled["channels"],
    }


def exercise_explicit_conflicts(page, client, destination):
    """ONR-001: actual file inputs, stale preflight, preserved history and all exports."""
    from playwright.sync_api import expect

    agreements = json.loads((ROOT / "fixtures/agreements.json").read_text())
    agreements[0]["matching"]["explicit"] = {"C-001": ["S-002"]}
    conflict_file = destination / "conflicting-agreements.json"
    conflict_file.write_text(json.dumps(agreements))
    corrected = deepcopy(agreements)
    corrected[0]["matching"]["explicit"] = {"C-001": ["S-001"]}
    corrected_file = destination / "corrected-agreements.json"
    corrected_file.write_text(json.dumps(corrected))

    def import_lot(agreement_file, label):
        page.locator('[data-view="new"]').click()
        expect(page.locator("#file-shipments")).to_be_attached()
        page.locator("#audit-label").fill(label)
        for role, filename in (("shipments", "operaciones.xlsx"), ("charges", "liquidacion.csv")):
            page.locator(f"#file-{role}").set_input_files(ROOT / "fixtures" / filename)
            page.locator(f"#mapping-file-{role}").set_input_files(ROOT / "fixtures" / f"mapping-{role}.json")
            expect(page.locator(f"#mapping-{role}")).to_have_value(
                (ROOT / "fixtures" / f"mapping-{role}.json").read_text()
            )
            page.locator(f"#validate-{role}").click()
            expect(page.locator(f"#result-{role}")).to_contain_text("aceptadas")
        page.locator("#goto-step-2").click()
        page.locator("#agreement-file").set_input_files(agreement_file)
        expect(page.locator("#agreements")).to_have_value(
            json.dumps(json.loads(agreement_file.read_text()), indent=2, ensure_ascii=False)
        )

    runs_before = len(client.get("/api/runs").json())
    import_lot(conflict_file, "ONR-001 vínculo contradictorio")
    held = []

    def hold_preflight(route):
        held.append((route, route.fetch()))

    page.route("**/api/audit/preflight", hold_preflight)
    page.locator("#goto-step-3").click()
    for _ in range(100):
        if held:
            break
        page.wait_for_timeout(20)
    assert held
    expect(page.locator("#matching-progress")).to_be_visible()
    expect(page.locator("#execute")).to_be_disabled()
    page.locator("#step-nav-2").click()
    page.locator("#agreement-file").set_input_files(corrected_file)
    expect(page.locator("#agreements")).to_have_value(json.dumps(corrected, indent=2, ensure_ascii=False))
    held[0][0].fulfill(response=held[0][1])
    page.unroute("**/api/audit/preflight", hold_preflight)
    page.wait_for_timeout(100)
    expect(page.locator("#step-panel-2")).to_be_visible()
    expect(page.locator("#matching-check-step3")).to_be_empty()
    page.locator("#goto-step-3").click()
    expect(page.locator("#step-panel-3")).to_be_visible()
    expect(page.locator("#matching-check-step3")).to_contain_text("0 contradictoria(s)")

    # A failed check must remain recoverable and must not persist a run.
    page.locator("#back-to-step-2").click()
    page.locator("#agreement-file").set_input_files(conflict_file)
    expect(page.locator("#agreements")).to_have_value(json.dumps(agreements, indent=2, ensure_ascii=False))
    page.route(
        "**/api/audit/preflight",
        lambda route: route.fulfill(
            status=503,
            content_type="application/json",
            body=json.dumps({"error": "Verificación temporalmente no disponible. Reintentar."}),
        ),
    )
    page.locator("#goto-step-3").click()
    expect(page.locator("#notice")).to_contain_text("Reintentar")
    expect(page.locator("#step-panel-2")).to_be_visible()
    assert len(client.get("/api/runs").json()) == runs_before
    page.unroute("**/api/audit/preflight")
    page.locator("#step-nav-4").click()  # direct navigation must also check
    expect(page.locator("#step-panel-4")).to_be_visible()
    expect(page.locator("#matching-check-step4")).to_contain_text("1 contradictoria(s)")
    expect(page.locator("#matching-check-step4")).to_contain_text("S-001")
    expect(page.locator("#matching-check-step4")).to_contain_text("S-002")
    expect(page.locator("#notice")).not_to_be_visible()
    expect(page.locator("#step-summary-3-text")).to_contain_text("vinculación(es) en revisión")
    page.screenshot(path=str(destination / "onr001-preflight.png"), full_page=True)
    page.locator("#back-to-step-3").click()
    expect(page.locator("#matching-check-step3")).to_contain_text("no confirmarán diferencias")
    page.locator("#goto-step-4").click()
    expect(page.locator("#step-panel-4")).to_be_visible()
    page.locator("#execute").click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    saved = next(r for r in client.get("/api/runs").json() if r["label"] == "ONR-001 vínculo contradictorio")
    run = client.get("/api/runs/" + saved["id"]).json()
    original = deepcopy(run["result"])
    by_charge = {cid: f for f in original["findings"] for cid in f["charge_ids"]}
    assert len(original["findings"]) == 44
    assert by_charge["C-001"]["charge_ids"] == ["C-001"]
    assert by_charge["C-001"]["status"] == by_charge["C-002"]["status"] == "REVIEW"
    assert by_charge["C-001"]["expected"] is None and by_charge["C-001"]["difference"] is None
    assert by_charge["C-001"]["confirmed_difference"] == by_charge["C-002"]["confirmed_difference"] == "0"
    assert original["summary"]["currencies"]["ARS"]["confirmed_overcharge"] == "0"
    assert original["summary"]["currencies"]["ARS"]["confirmed_net_difference"] == "-75"
    assert original["summary"]["currencies"]["ARS"]["actual"] == "43719.4"
    observations = observe(page, run)
    page.locator("#filter-status").select_option("REVIEW")
    page.locator(f'[data-finding="{by_charge["C-001"]["id"]}"]').click()
    expect(page.locator("#detail-content .matching-conflicts")).to_contain_text("S-001")
    expect(page.locator("#detail-content .matching-conflicts")).to_contain_text("S-002")
    expect(page.locator("#detail-content")).to_contain_text("Primero se debe resolver la vinculación")
    expect(page.locator("#detail-content")).to_contain_text("Pendiente por vinculación")
    expect(page.locator("#detail-content")).not_to_contain_text("Sin versión aplicable")
    expect(page.locator("#detail-content")).not_to_contain_text("Sin regla aplicable")
    expect(page.locator("#detail-content .arithmetic-callout")).to_contain_text("Cálculo pendiente")
    page.screenshot(path=str(destination / "onr001-detail.png"), full_page=True)
    page.locator("#detail-content .matching-conflicts").scroll_into_view_if_needed()
    expect(page.locator("#detail-content .matching-conflicts")).to_be_in_viewport()
    page.screenshot(path=str(destination / "onr001-matching.png"), full_page=True)
    page.locator("#actor").fill("Operador sintético ONR-001")
    page.locator("#action").select_option("EXCEPTION_ACCEPTED")
    page.locator("#decision-note").fill(
        "Esta decisión humana no confirma el importe ni resuelve la vinculación"
    )
    page.locator('#decision-form button[type="submit"]').click()
    expect(page.locator(".history").last).to_contain_text("Excepción aceptada")
    page.locator("#close-detail").click()
    run = client.get("/api/runs/" + saved["id"]).json()
    assert run["result"] == original and len(run["decisions"]) == 1
    page.locator("#replay").click()
    expect(page.locator("#notice")).to_contain_text("Reproducción idéntica")
    for fmt, filename in (
        ("canonical", "audit.json"),
        ("xlsx", "audit.xlsx"),
        ("html", "audit.html"),
        ("zip", "audit.zip"),
    ):
        with page.expect_download() as downloading:
            page.locator(f'a[href$="/export/{fmt}"]').click()
        downloading.value.save_as(destination / ("onr001-" + filename))
    assert json.loads((destination / "onr001-audit.json").read_text()) == run
    bundle_dir = destination / "onr001-export"
    with zipfile.ZipFile(destination / "onr001-audit.zip") as bundle:
        assert bundle.testzip() is None
        bundle.extractall(bundle_dir)  # only our own local producer
    reconciled = reconcile(bundle_dir, api_run=run)
    assert not reconciled["errors"], reconciled
    reconciled["channels"]["ui"] = f"{len(observations)} actual DOM rows; exact cells and statuses"
    verification = subprocess.run(
        [
            sys.executable,
            "-m",
            "freight_audit.cli",
            "verify-bundle",
            str(destination / "onr001-audit.zip"),
            "--replay",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    assert json.loads(verification.stdout)["identical"]
    (destination / "onr001-bundle-replay.json").write_text(verification.stdout)
    (destination / "onr001-observed-ui.json").write_text(
        json.dumps(observations, ensure_ascii=False, indent=2)
    )

    import_lot(corrected_file, "ONR-001 vínculo corregido")
    page.locator("#goto-step-3").click()
    expect(page.locator("#matching-check-step3")).to_contain_text("0 contradictoria(s)")
    page.locator("#goto-step-4").click()
    expect(page.locator("#step-panel-4")).to_be_visible()
    page.locator("#execute").click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    corrected_run = next(
        r for r in client.get("/api/runs").json() if r["label"] == "ONR-001 vínculo corregido"
    )
    corrected_run = client.get("/api/runs/" + corrected_run["id"]).json()
    fixed = {cid: f for f in corrected_run["result"]["findings"] for cid in f["charge_ids"]}
    assert fixed["C-001"]["status"] == "PASS"
    assert (fixed["C-002"]["status"], fixed["C-002"]["confirmed_difference"]) == ("FAIL", "50")
    assert corrected_run["id"] != run["id"]
    assert client.get("/api/runs/" + run["id"]).json()["result"] == original
    page.locator("#back").click()
    page.locator(f'[data-run="{run["id"]}"]').click()
    expect(page.locator("#findings tr[data-finding-id]").first).to_be_visible()
    assert observe(page, run)  # reopen the old REVIEW run after a corrected audit
    return {
        "conflicting_run": run["id"],
        "corrected_run": corrected_run["id"],
        "confirmed_net_conflict": "-75",
        "confirmed_net_corrected": "-25",
        "rows_observed": len(observations),
        "channels": reconciled["channels"],
        "stale_preflight_discarded": True,
        "retry_verified": True,
        "decision_preserved_uncertainty": True,
        "replay_identical": True,
    }


def exercise_manual_mapping(page, destination):
    """ONR-003: the visible source follows the actual JSON through file and selector changes."""
    from playwright.sync_api import expect

    # Reopening a wizard must replace the old form before the config request completes.
    page.locator('[data-view="new"]').click()
    expect(page.locator("#file-shipments")).to_be_attached()
    page.locator("#file-shipments").set_input_files(ROOT / "fixtures/operaciones-invalidas.csv")
    expect(page.locator("#format-title-shipments")).to_contain_text("operaciones-demo@1")
    manual = ROOT / "fixtures/mapping-invalid.json"
    page.locator("#mapping-file-shipments").set_input_files(manual)
    expect(page.locator("#format-title-shipments")).to_have_text("Mapping manual: errores-demo@1")
    expect(page.locator("#saved-shipments")).to_have_value("")
    expect(page.locator("#mapping-shipments")).to_have_value(manual.read_text())
    page.locator("#validate-shipments").click()
    expect(page.locator("#result-shipments")).to_contain_text("0 filas aceptadas · 1 rechazadas")
    expect(page.locator("#notice")).to_contain_text("0 aceptadas, 1 rechazadas y 2 incidencias")
    expect(page.locator("#result-shipments .import-issues")).to_contain_text("2 incidencia(s)")
    page.screenshot(path=str(destination / "onr003-manual-mapping.png"), full_page=True)

    page.locator("#file-shipments").set_input_files(
        {
            "name": "operaciones-invalidas-copia.csv",
            "mimeType": "text/csv",
            "buffer": (ROOT / "fixtures/operaciones-invalidas.csv").read_bytes(),
        }
    )
    expect(page.locator("#format-title-shipments")).to_have_text("Mapping manual: errores-demo@1")
    page.locator("#toggle-mapping-shipments").click()
    saved_hash = page.locator("#saved-shipments option").nth(1).get_attribute("value")
    page.locator("#saved-shipments").select_option(saved_hash)
    expect(page.locator("#format-title-shipments")).to_have_text("Formato seleccionado: operaciones-demo@1")
    page.locator("#toggle-advanced-shipments").click()
    page.locator("#mapping-shipments").fill(manual.read_text())
    expect(page.locator("#format-title-shipments")).to_have_text("Mapping manual: errores-demo@1")
    expect(page.locator("#saved-shipments")).to_have_value("")
    assert page.locator("[style]:not([style=''])").count() == 0
    page.locator('[data-view="audits"]').click()
    expect(page.locator("#file-shipments")).to_have_count(0)
    return {
        "loaded_mapping": "errores-demo@1",
        "saved_selection_cleared": True,
        "manual_survives_file_change": True,
    }


def exercise_other_views(page, destination):
    """The CSP-safe presentation is also exercised outside the wizard and result."""
    from playwright.sync_api import expect

    page.locator('[data-view="configs"]').click()
    expect(page.locator("#advanced-config-panel")).to_be_attached()
    for name, versions, rules in (("A", 3, 6), ("B", 1, 1), ("C", 1, 3)):
        card = page.locator(".run-card-rich", has_text=f"Acuerdo FICTICIO {name}")
        expect(card).to_contain_text(f"Versiones: {versions}")
        expect(card).to_contain_text(f"{rules} regla(s) configuradas")
        card.locator(".agreement-summary-detail summary").click()
        expect(card.locator(".agreement-summary-detail li").first).to_be_visible()
    assert page.locator("[style]:not([style=''])").count() == 0
    assert page.locator(".run-list").first.evaluate("element => getComputedStyle(element).display") == "flex"
    page.screenshot(path=str(destination / "onr005-configs.png"))
    page.locator('[data-view="guide"]').click()
    expect(page.locator(".guide")).to_be_visible()
    assert page.locator("[style]:not([style=''])").count() == 0
    page.screenshot(path=str(destination / "onr005-guide.png"))
    page.locator('[data-view="audits"]').click()
    expect(page.locator("#runs-items")).to_be_visible()
    return {"configs": True, "guide": True, "nonempty_inline_styles": 0}


def main():
    from playwright.sync_api import sync_playwright

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "output/playwright/rigor")
    parser.add_argument("--installed-root", type=Path)
    args = parser.parse_args()
    args.output_dir = args.output_dir.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if (args.output_dir / "server.log").exists():
        parser.error("Output directory already used; preserve evidence and choose a new directory")
    errors = []
    console_errors = []
    with tempfile.TemporaryDirectory(prefix="calibre-browser-") as td:
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            port = listener.getsockname()[1]
        env = os.environ.copy()
        env.pop("PYTHONPATH", None)
        if not args.installed_root:
            env["PYTHONPATH"] = str(ROOT / "src")
        probe = subprocess.check_output(
            [sys.executable, "-c", "import freight_audit; print(freight_audit.__file__)"],
            cwd=td,
            env=env,
            text=True,
        ).strip()
        if args.installed_root:
            assert Path(probe).resolve().is_relative_to(args.installed_root.resolve()), probe
        script_hash = hashlib.sha256((Path(probe).parent / "static/app.js").read_bytes()).hexdigest()
        assert (
            script_hash == hashlib.sha256((ROOT / "src/freight_audit/static/app.js").read_bytes()).hexdigest()
        ), "Stale UI artifact"
        for path in (ROOT / "src/freight_audit").rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts:
                installed = Path(probe).parent / path.relative_to(ROOT / "src/freight_audit")
                assert installed.read_bytes() == path.read_bytes(), f"Stale product file: {path.name}"
        with (args.output_dir / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "freight_audit.cli",
                    "--db",
                    str(Path(td) / "audit.db"),
                    "serve",
                    "--port",
                    str(port),
                ],
                cwd=td,
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                with httpx.Client(base_url=f"http://127.0.0.1:{port}", timeout=30) as client:
                    for _ in range(100):
                        assert server.poll() is None, "Owned server exited; refusing to use another process"
                        try:
                            token = client.get("/api/session").json()["token"]
                            break
                        except httpx.ConnectError:
                            time.sleep(0.1)
                    else:
                        raise AssertionError("Server startup timed out")
                    client.headers["X-Freight-Local"] = token
                    assert client.get("/api/runs").json() == []
                    listener_scope = assert_ipv4_loopback_listener(port)
                    with sync_playwright() as pw:
                        browser = pw.chromium.launch()
                        context = browser.new_context()
                        context.tracing.start(screenshots=True, snapshots=True, sources=True)
                        page = context.new_page()
                        page.on("pageerror", lambda error: errors.append(str(error)))
                        page.on(
                            "console",
                            lambda message: (
                                console_errors.append(message.text) if message.type == "error" else None
                            ),
                        )
                        try:
                            network_boundary = exercise_cross_origin(context, client, token, port)
                            result = exercise(page, client, args.output_dir)
                            result["onr003"] = exercise_manual_mapping(page, args.output_dir)
                            result["onr005_views"] = exercise_other_views(page, args.output_dir)
                            result["onr001"] = exercise_explicit_conflicts(page, client, args.output_dir)
                            from scripts.browser_hardening import (
                                exercise_loading_and_paging,
                                exercise_uncertainty,
                            )

                            result["uncertainty"] = exercise_uncertainty(
                                page, client, args.output_dir, observe
                            )
                            result["loading_and_paging"] = exercise_loading_and_paging(
                                page, client, args.output_dir, ROOT
                            )
                            assert not errors, errors
                            csp_rejections = [
                                message
                                for message in console_errors
                                if "Content Security Policy" in message
                                or "Refused to apply inline style" in message
                            ]
                            assert not csp_rejections, csp_rejections
                            assert all(
                                "Failed to load resource" in message
                                and ("422" in message or "503" in message)
                                for message in console_errors
                            ), console_errors
                            result.update(
                                product_path=probe,
                                ui_sha256=script_hash,
                                browser=browser.version,
                                listener_scope=listener_scope,
                                network_boundary=network_boundary,
                                console_errors=console_errors,
                                csp_rejections=csp_rejections,
                                passed=True,
                            )
                            (args.output_dir / "result.json").write_text(json.dumps(result, indent=2))
                            print(json.dumps(result, indent=2))
                        finally:
                            context.tracing.stop(path=str(args.output_dir / "trace.zip"))
                            browser.close()
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()


if __name__ == "__main__":
    main()
